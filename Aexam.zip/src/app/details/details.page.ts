import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-details',
  templateUrl: './details.page.html',
  styleUrls: ['./details.page.scss'],
})
export class DetailsPage implements OnInit {
  header: HttpHeaders;
  val ;
  id = '';
  new_id = '';

  constructor(private activatedRoute: ActivatedRoute, private http: HttpClient) { }

  ngOnInit() {
    this.activatedRoute.params.subscribe((value) => {
      this.id = value.id;
      this.getUsers( this.id )
      console.log(this.id);

    });

  }

  async getUsers(id) {
    this.header = new HttpHeaders({
      'Content-type': 'application/json'
    });
    await this.http.get('https://jsonplaceholder.typicode.com/users/' + id ).subscribe((item) => {
      this.val = <Array<any>>item;

      console.log(this.val);
      console.log('The id is ' + this.id);

    });
  }

}
