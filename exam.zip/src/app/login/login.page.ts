import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';
import { from, observable } from 'rxjs';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {
  WsApi = 'https://jsonplaceholder.typicode.com/users';
  // WsApi = 'https://jsonplaceholder.typicode.com/posts';

  header: HttpHeaders;
  val ;

  constructor(private router: Router, private http: HttpClient) { }
  ngOnInit() {

    this.getUsers();
  }

  gotoDetails(id) {
    this.router.navigate(['details', id]);
  }


  async getUsers() {
    this.header = new HttpHeaders({
      'Content-type': 'application/json'
    });
    await this.http.get(this.WsApi ).subscribe((item) => {
      this.val = <Array<any>>item;

      console.log(this.val);

    });
  }

}
